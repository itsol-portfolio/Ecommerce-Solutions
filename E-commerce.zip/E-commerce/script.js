const products = [
  { id: 1, name: "Laptop", price: 800 },
  { id: 2, name: "Headphones", price: 100 },
  { id: 3, name: "Smartphone", price: 600 }
];

let cart = [];

const productContainer = document.getElementById('products');
const cartContainer = document.getElementById('cartItems');
const totalText = document.getElementById('total');

products.forEach(p => {
  const div = document.createElement('div');
  div.className = 'product';
  div.innerHTML = `<h3>${p.name}</h3><p>Price: $${p.price}</p>
                   <button onclick="addToCart(${p.id})">Add to Cart</button>`;
  productContainer.appendChild(div);
});

function addToCart(id) {
  const product = products.find(p => p.id === id);
  cart.push(product);
  updateCart();
}

function updateCart() {
  cartContainer.innerHTML = '';
  let total = 0;
  cart.forEach(item => {
    const li = document.createElement('li');
    li.textContent = `${item.name} - $${item.price}`;
    cartContainer.appendChild(li);
    total += item.price;
  });
  totalText.textContent = `Total: $${total}`;
}

document.getElementById('checkoutBtn').addEventListener('click', () => {
  alert('Checkout Complete!');
  cart = [];
  updateCart();
});
